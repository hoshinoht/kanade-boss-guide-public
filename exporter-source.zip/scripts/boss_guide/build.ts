import { copyFileSync, lstatSync, mkdirSync, readdirSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import type { KnowledgeDoc } from '../../web/packages/api-types/src/manual';
import { bossPage, indexPage, type Boss } from './render';

const root = realpathSync(join(import.meta.dir, '../..'));
const [, , destination, ...extra] = process.argv;
if (!destination || extra.length) throw new Error('Usage: bun --no-env-file scripts/boss_guide/build.ts <new-output-directory>');
const output = resolve(destination);
const readYaml = <T>(path: string) => Bun.YAML.parse(readFileSync(join(root, path), 'utf8')) as T;
const { bosses: catalog } = readYaml<{ bosses: Record<string, { full: string; level: number; portrait?: string }> }>('boss/bosses.yaml');
const { researched_as_of: date } = readYaml<{ researched_as_of: string }>('boss/knowledge/_meta.yaml');
const catalogKeys = new Map(Object.keys(catalog).map((key) => [key.toLowerCase(), key]));
const keyPattern = /^[a-z0-9][a-z0-9-]*$/i;
const assets = new Map<string, string>();

function asset(directory: string, basename: string, slug: string, role: string, extension: string) {
  const source = join(root, directory, `${basename}.${extension}`);
  const info = lstatSync(source, { throwIfNoEntry: false });
  if (!info) return;
  if (!info.isFile() || realpathSync(source) !== source) {
    throw new Error(`Expected a regular media file at ${source}`);
  }
  const target = `assets/${slug}-${role}.${extension}`;
  assets.set(target, source);
  return target;
}

const bosses: Boss[] = [];
const seen = new Set<string>();
for (const file of readdirSync(join(root, 'boss/knowledge'), { withFileTypes: true })) {
  if (!file.isFile() || file.name.startsWith('_') || !file.name.endsWith('.yaml')) continue;
  const doc = readYaml<KnowledgeDoc>(`boss/knowledge/${file.name}`);
  const slug = doc.boss.toLowerCase();
  if (!keyPattern.test(slug) || file.name !== `${slug}.yaml` || seen.has(slug)) {
    throw new Error(`Invalid or duplicate guide key in ${file.name}`);
  }
  seen.add(slug);
  const key = catalogKeys.get(slug);
  const entry = key ? catalog[key] : undefined;
  if (!entry && !doc.event) throw new Error(`Missing catalog entry or event for ${file.name}`);
  const basename = entry?.portrait ?? key ?? doc.boss;
  if (!keyPattern.test(basename)) throw new Error(`Invalid media basename for ${file.name}`);
  const portrait = asset('boss/portraits/icon', basename, slug, 'portrait', 'png')
    ?? asset('boss/portraits', basename, slug, 'portrait', 'png');
  const image = asset('boss/artwork/entry', basename, slug, 'entry', 'png') ?? portrait;
  if (!image) throw new Error(`Missing curated artwork for ${doc.boss}`);
  const video = asset('boss/artwork/animated', basename, slug, 'animation', 'mp4');
  bosses.push({ slug, name: entry?.full ?? doc.boss, level: entry?.level, portrait: portrait ?? image, image, video, doc });
}
if (!bosses.length) throw new Error('No boss guides found');
bosses.sort((a, b) => (a.level ?? Infinity) - (b.level ?? Infinity) || a.name.localeCompare(b.name, 'en'));

const pages = bosses.map((boss) => [boss.slug, bossPage(boss, bosses, date)] as const);
mkdirSync(output);
mkdirSync(join(output, 'assets'));
for (const [target, source] of assets) copyFileSync(source, join(output, target));
copyFileSync(join(import.meta.dir, 'guide.css'), join(output, 'guide.css'));
copyFileSync(join(import.meta.dir, 'README.md'), join(output, 'README.md'));
copyFileSync(join(root, 'LICENSE'), join(output, 'LICENSE'));
writeFileSync(join(output, '.nojekyll'), '');
writeFileSync(join(output, 'index.html'), indexPage(bosses));
for (const [slug, html] of pages) {
  mkdirSync(join(output, slug));
  writeFileSync(join(output, slug, 'index.html'), html);
}
console.log(`Built ${bosses.length} guides and ${assets.size} media files in ${output}`);
