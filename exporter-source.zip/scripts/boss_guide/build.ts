import { copyFileSync, lstatSync, mkdirSync, readdirSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import type { KnowledgeDoc } from '../../web/packages/api-types/src/manual';
import { bossPage, bossPath, indexPage, type Boss } from './render';

const root = realpathSync(join(import.meta.dir, '../..'));
const [, , destination, ...extra] = process.argv;
if (!destination || extra.length) throw new Error('Usage: bun --no-env-file scripts/boss_guide/build.ts <new-output-directory>');
const output = resolve(destination);
const readYaml = <T>(path: string) => Bun.YAML.parse(readFileSync(join(root, path), 'utf8')) as T;
const { bosses: catalog } = readYaml<{ bosses: Record<string, { full: string; level: number; portrait?: string }> }>('boss/bosses.yaml');
const { researched_as_of: date } = readYaml<{ researched_as_of: string }>('boss/knowledge/_meta.yaml');
const catalogKeys = new Map(Object.keys(catalog).map((key) => [key.toLowerCase(), key]));
const catalogOrder = new Map([...catalogKeys.keys()].map((key, index) => [key, index]));
const keyPattern = /^[a-z0-9][a-z0-9-]*$/i;
const assets = new Map<string, string>();

function asset(directory: string, basename: string, slug: string, role: string, extension: string) {
  const source = join(root, directory, `${basename}.${extension}`);
  const info = lstatSync(source, { throwIfNoEntry: false });
  if (!info) return;
  if (!info.isFile() || realpathSync(source) !== source) {
    throw new Error(`Expected a regular media file at ${source}`);
  }
  const target = `assets/${slug}-${role}.${extension}`;
  assets.set(target, source);
  return target;
}

const bosses: Boss[] = [];
const seen = new Set<string>();
for (const file of readdirSync(join(root, 'boss/knowledge'), { withFileTypes: true })) {
  if (!file.isFile() || file.name.startsWith('_') || !file.name.endsWith('.yaml')) continue;
  const doc = readYaml<KnowledgeDoc>(`boss/knowledge/${file.name}`);
  const slug = doc.boss.toLowerCase();
  if (!keyPattern.test(slug) || file.name !== `${slug}.yaml` || seen.has(slug)) {
    throw new Error(`Invalid or duplicate guide key in ${file.name}`);
  }
  seen.add(slug);
  const key = catalogKeys.get(slug);
  const entry = key ? catalog[key] : undefined;
  if (!entry && !doc.event) throw new Error(`Missing catalog entry or event for ${file.name}`);
  const basename = entry?.portrait ?? key ?? doc.boss;
  if (!keyPattern.test(basename)) throw new Error(`Invalid media basename for ${file.name}`);
  const thumbnail = asset('boss/portraits/icon', basename, slug, 'icon', 'png');
  const portrait = asset('boss/portraits', basename, slug, 'portrait', 'png') ?? thumbnail;
  const image = asset('boss/artwork/entry', basename, slug, 'entry', 'png') ?? portrait;
  if (!image) throw new Error(`Missing curated artwork for ${doc.boss}`);
  const video = asset('boss/artwork/animated', basename, slug, 'animation', 'mp4');
  bosses.push({ slug, name: entry?.full ?? doc.boss, level: entry?.level, thumbnail: thumbnail ?? portrait ?? image, portrait: portrait ?? image, image, video, doc });
}
if (!bosses.length) throw new Error('No boss guides found');
bosses.sort((a, b) => (a.level ?? Infinity) - (b.level ?? Infinity)
  || (catalogOrder.get(a.slug) ?? Infinity) - (catalogOrder.get(b.slug) ?? Infinity)
  || a.name.localeCompare(b.name, 'en'));

const pages = bosses.flatMap((boss) => {
  const facts = boss.doc.difficulties ?? [];
  return [
    [bossPath(boss), bossPage(boss, bosses, date, '../', facts[0])] as const,
    ...facts.slice(1).map((fact) => [bossPath(boss, fact), bossPage(boss, bosses, date, '../../', fact)] as const),
  ];
});
const fonts = new Map<string, string>();
for (const [name, weights] of [['solway', [800]], ['zilla-slab', [400, 700]], ['maple-mono', [700]]] as const) {
  const directory = join(root, 'web/packages/tokens/node_modules/@fontsource', name);
  const license = join(directory, 'LICENSE');
  if (!lstatSync(license, { throwIfNoEntry: false })) throw new Error('Install the locked web dependencies first: cd web && bun install --frozen-lockfile');
  fonts.set(`${name}-OFL.txt`, license);
  for (const weight of weights) {
    const filename = `${name}-latin-${weight}-normal.woff2`;
    fonts.set(filename, join(directory, 'files', filename));
  }
}
mkdirSync(output);
mkdirSync(join(output, 'assets'));
for (const [target, source] of assets) copyFileSync(source, join(output, target));
for (const [name, source] of fonts) copyFileSync(source, join(output, 'assets', name));
copyFileSync(join(import.meta.dir, 'guide.css'), join(output, 'guide.css'));
copyFileSync(join(import.meta.dir, 'README.md'), join(output, 'README.md'));
copyFileSync(join(root, 'LICENSE'), join(output, 'LICENSE'));
writeFileSync(join(output, '.nojekyll'), '');
writeFileSync(join(output, 'index.html'), indexPage(bosses));
for (const [path, html] of pages) {
  const filename = join(output, path, 'index.html');
  mkdirSync(dirname(filename), { recursive: true });
  writeFileSync(filename, html);
}
console.log(`Built ${bosses.length} guides (${pages.length} boss and difficulty pages) and ${assets.size} media files in ${output}`);
