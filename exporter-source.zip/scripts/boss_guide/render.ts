import type { DifficultyFacts, GuideItem, KnowledgeDoc, Mechanic, Mission } from '../../web/packages/api-types/src/manual';
import { LEVEL_WORD, SERIES_NAME, difficultyNotes, factTiles, guideTabs, hpBreakdown, itemParts, phaseRuns, runLabel, spellHp, stopLabel } from '../../web/packages/ui/src/bosses/guide';

export interface Boss {
  slug: string;
  name: string;
  level?: number;
  thumbnail: string;
  portrait: string;
  image: string;
  video?: string;
  doc: KnowledgeDoc;
}

const upstream = 'https://github.com/hoshinoht/kanade-bot';
const escape = (value: string | number) => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;')
  .replaceAll('>', '&gt;').replaceAll('"', '&quot;');

export function bossPath(boss: Boss, fact?: DifficultyFacts) {
  const suffix = fact && fact !== boss.doc.difficulties?.[0] ? `${fact.name.toLowerCase()}/` : '';
  return `${boss.slug}/${suffix}`;
}

function page(title: string, lead: string, base: string, bosses: Boss[], body: string, current?: Boss) {
  const count = bosses.reduce((total, boss) => total + (boss.doc.difficulties?.length ?? 0), 0);
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="${escape(lead)}">
  <title>${escape(title)}</title>
  <link rel="stylesheet" href="${base}guide.css">
</head>
<body>
  <a class="skip" href="#guide">Skip to guide</a>
  <header class="page-line"><a href="${base || './'}">Bosses</a> <span><b>${bosses.length}</b> bosses · <b>${count}</b> difficulties</span></header>
  <main class="window" aria-label="Kanade Boss Guide">
    <div class="window-bar"><strong>The in-game list</strong><span>Level order</span></div>
    <div class="window-body${current ? ' window-body--detail' : ''}">
      ${catalog(bosses, base, current)}
      ${body}
    </div>
  </main>
  <footer>Part of the <a href="${upstream}">Kanade project</a>.</footer>
</body>
</html>\n`.replace(/[ \t]+$/gm, '');
}

function catalog(bosses: Boss[], base: string, current?: Boss) {
  const groups = [
    ['', bosses.filter((boss) => !boss.doc.event)],
    ['Event bosses', bosses.filter((boss) => boss.doc.event)],
  ] as const;
  return `<nav class="catalog" aria-label="Boss catalog">
    ${groups.filter(([, entries]) => entries.length).map(([label, entries]) => `${label ? `<h2 class="cap">${label}</h2>` : ''}
      <ul>${entries.map((boss) => `<li><a href="${base}${bossPath(boss)}"${boss === current ? ' aria-current="true"' : ''}>
        <img class="portrait" src="${base}${boss.thumbnail}" alt="" width="34" height="34">
        <span><strong>${escape(boss.name)}</strong>${boss.level ? `<small class="mono">Lv. ${escape(boss.level)}</small>` : ''}</span>
        ${boss.doc.event ? '<span class="catalog-chip">Seasonal boss</span>' : ''}
      </a></li>`).join('\n')}</ul>`).join('\n')}
  </nav>`;
}

export function indexPage(bosses: Boss[]) {
  const lead = 'Fight mechanics, phase notes, and difficulty stats for MapleSEA bosses.';
  return page('Kanade Boss Guide', lead, '', bosses, `<div id="guide" class="catalog-intro" tabindex="-1">
    <p class="cap">Checked-in boss knowledge</p><h1>MapleSEA Boss Guide</h1>
    <p class="guide-lead">${lead}</p><p>Choose a boss to open its guide.</p>
  </div>`);
}

function rows(items: GuideItem[] = []) {
  if (!items.length) return '';
  return `<ul class="guide-rows">${items.map((item) => {
    const { title, text } = itemParts(item);
    return `<li>${title ? `<strong>${escape(title)}</strong> ` : ''}${escape(text)}</li>`;
  }).join('')}</ul>`;
}

function mechanicCard(mechanic: Mechanic) {
  let content;
  if (mechanic.kind === 'ledger') {
    content = `<dl class="ledger">${mechanic.rows.map(({ label, value, direction }) => `<div><dt>${escape(label)}</dt><dd>${direction ? (direction === 'up' ? '↑ ' : '↓ ') : ''}${escape(value)}</dd></div>`).join('')}</dl>`;
  } else {
    const bands = mechanic.kind === 'zones'
      ? mechanic.zones.map(({ name, sub, tone }) => ({ label: name, sub, tone, span: 1 }))
      : mechanic.bands.map((band) => ({ ...band, sub: undefined }));
    content = `<ul class="bands">${bands.map(({ label, sub, tone, span }) => `<li data-tone="${escape(tone ?? '')}" style="flex-grow:${Number(span)}"><strong>${escape(label)}</strong>${sub ? `<small>${escape(sub)}</small>` : ''}</li>`).join('')}</ul>`;
  }
  return `<div class="guide-card"><h3>${escape(mechanic.title)}</h3>${content}${mechanic.note ? `<p>${escape(mechanic.note)}</p>` : ''}</div>`;
}

function missionCard(mission: Mission, current: Boss, bosses: Boss[], base: string) {
  const stops = bosses.flatMap((boss) => (boss.doc.difficulties ?? []).flatMap((fact) =>
    fact.mission?.series === mission.series ? [{ boss, order: fact.mission.order, fact }] : [],
  )).sort((a, b) => a.order - b.order);
  const modifier = mission.modifier;
  return `<div class="guide-card"><h4>${escape(SERIES_NAME[mission.series])} · ${escape(mission.title)}</h4>
    ${modifier ? `<p>${modifier.direction === 'up' ? '↑' : '↓'} ${escape(modifier.text)}</p>` : ''}
    ${mission.needs ? `<p>${escape(mission.needs)}</p>` : ''}${rows(mission.rules)}
    <ul class="pills">${stops.map(({ boss, order, fact }) => {
      const label = `${escape(stopLabel(mission.series, order))} · ${escape(boss.name)}`;
      return `<li>${boss === current && order === mission.order ? `<strong>${label}</strong>` : `<a href="${base}${bossPath(boss, fact)}#facts">${label}</a>`}</li>`;
    }).join('')}</ul></div>`;
}

function difficulty(fact: DifficultyFacts, boss: Boss, bosses: Boss[], base: string) {
  const hp = hpBreakdown(fact.hp);
  const tiles = factTiles(fact);
  const hpValue = (value: string) => `<abbr title="${escape(spellHp(value))}">${escape(value)}</abbr>`;
  return `<section class="difficulty" id="facts" aria-label="${escape(fact.name)} facts">
  ${fact.mission ? missionCard(fact.mission, boss, bosses, base) : ''}
  ${tiles.length ? `<dl class="guide-tiles">${tiles.map(({ label, value, sub }) => `<div><dt>${escape(label)}</dt><dd>${escape(value)}${sub ? `<small>${escape(sub)}</small>` : ''}</dd></div>`).join('')}</dl>` : ''}
  ${hp ? `<details class="guide-hp" id="hp"><summary><span class="cap">HP</span>${hp.total ? ` <span class="mono">${hpValue(hp.total)} total</span>` : ''}</summary>
    <dl class="ledger">${hp.phases.map(({ name, total, bars }) => `<div><dt>${escape(name)}</dt><dd>${bars.length > 1 ? `${bars.length} × ` : ''}${hpValue(bars[0]!)}${total ? ` (${hpValue(total)} total)` : ''}</dd></div>`).join('')}</dl></details>` : ''}
  ${rows(difficultyNotes(boss.doc, fact))}
</section>`;
}

export function bossPage(boss: Boss, bosses: Boss[], date: string, base: string, fact?: DifficultyFacts) {
  const { doc } = boss;
  const lead = doc.lead ?? doc.summary;
  const facts = doc.difficulties ?? [];
  const spec = fact?.recommended_spec;
  const tabs = new Map<string, number | null>(guideTabs(doc).map(({ id, count }) => [id, count]));
  const sections = [
    ['overview', 'Overview', `${doc.mechanics?.map(mechanicCard).join('') ?? ''}${rows(doc.core)}
      ${doc.danger.length ? `<h3>Danger</h3>${rows(doc.danger)}` : ''}${doc.tips.length ? `<h3>Tips</h3>${rows(doc.tips)}` : ''}`],
    ['phases', 'Phases', phaseRuns(doc.phases ?? []).map((run) => `<div class="phase-run">
      ${run.group ? `<h3>${escape(runLabel(run))}</h3>` : ''}
      ${run.phases.map(({ phase }) => `<details class="guide-card" data-tone="${escape(phase.tone ?? '')}" open><summary>${escape(phase.name)}${phase.tag ? ` <small>${escape(phase.tag)}</small>` : ''}</summary>${rows(phase.items)}</details>`).join('')}</div>`).join('')],
    ['strategies', 'Strategies', (doc.strategies ?? []).map((strategy) => `<div class="guide-card"><h3>${escape(strategy.name)}</h3>
      <small>${escape(LEVEL_WORD[strategy.risk])} risk · ${escape(LEVEL_WORD[strategy.damage])} damage requirement</small>
      <p>${escape(strategy.when)}</p><ol>${strategy.steps.map((step) => `<li>${escape(step)}</li>`).join('')}</ol><p><strong>Payoff</strong> ${escape(strategy.payoff)}</p></div>`).join('')],
    ['notes', 'Notes', `${rows(doc.notes)}${spec && (spec.value || spec.parties?.length) ? `<p><strong>Recommended · ${escape(fact!.name)}</strong> ${escape(spec.text)}</p>` : ''}`],
    ['sources', 'Sources', `<p>Research checked <time datetime="${escape(date)}">${escape(date)}</time>.</p>
      <ul class="guide-rows">${doc.sources.map((source) => {
        const url = new URL(source.url);
        if (url.protocol !== 'https:' || url.username || url.password) throw new Error(`Invalid source URL for ${boss.slug}`);
        return `<li><a href="${escape(url.href)}">${escape(source.title)}</a><small>${escape(source.author)} · ${escape(source.kind)}</small></li>`;
      }).join('')}</ul>`],
  ].filter(([, , content]) => content?.trim());
  const sectionLinks = sections.map(([id, label]) => `<li><a href="#${id}">${label}</a></li>`).join('');
  const sectionPills = sections.map(([id, label]) => {
    const count = tabs.get(id!);
    return `<li><a href="#${id}">${label}${count ? ` <span class="pill-count">${count}</span>` : ''}</a></li>`;
  }).join('');
  const title = [boss.name, fact?.name, 'Kanade Boss Guide'].filter(Boolean).join(' · ');
  return page(title, lead, base, bosses, `<article id="guide" tabindex="-1">
  <a class="catalog-back" href="${base}">← Back to the catalog</a>
  <header class="hero">
    <div class="hero-art" aria-hidden="true">
      <img src="${base}${boss.image}" alt="">
      ${boss.video ? `<video poster="${base}${boss.image}" muted autoplay loop playsinline preload="metadata" disablepictureinpicture disableremoteplayback>
        <source src="${base}${boss.video}" type="video/mp4" media="(prefers-reduced-motion: no-preference)">
      </video>` : ''}
    </div>
    <div class="hero-identity">
      <img class="portrait" src="${base}${boss.portrait}" alt="" width="72" height="72">
      <div><p class="cap">Checked-in boss knowledge</p><h1>${escape(boss.name)}</h1>
        <p class="hero-meta">Researched <time datetime="${escape(date)}">${escape(date)}</time>${boss.level ? ` · Lv. ${escape(boss.level)}` : ''}</p></div>
      ${doc.event ? `<span class="catalog-chip">${escape(doc.event.name)}</span>` : ''}
    </div>
    ${boss.video ? '<label class="hero-motion"><input type="checkbox" checked> Animate artwork</label>' : ''}
  </header>
  <div class="guide-layout">
    <div class="guide-content">
      ${fact ? `<nav id="difficulties" class="difficulty-switch" aria-label="Difficulty"><span class="cap">Difficulty</span><ul>${facts.map((choice) => `<li><a href="${base}${bossPath(boss, choice)}"${fact === choice ? ' aria-current="page"' : ''}>${escape(choice.name)}</a></li>`).join('')}</ul></nav>` : ''}
      <p class="guide-lead">${escape(lead)}</p>
      ${doc.event ? `<p class="event-note"><strong>Event boss.</strong> ${escape(doc.event.availability)}</p>` : ''}
      ${fact ? difficulty(fact, boss, bosses, base) : ''}
      <nav class="section-links" aria-label="Guide sections"><ul class="pills">${sectionPills}</ul></nav>
      ${sections.map(([id, label, content]) => `<section class="guide-section" id="${id}"><h2>${label}</h2>${content}</section>`).join('\n')}
    </div>
    <aside><nav class="toc" aria-label="On this page"><h2 class="cap">On this page</h2>
      ${fact ? `<ul><li><a href="#facts">Facts</a></li>${hpBreakdown(fact.hp) ? '<li><a href="#hp">HP</a></li>' : ''}</ul>` : ''}
      <h3 class="cap">Guide</h3><ul>${sectionLinks}</ul>
    </nav></aside>
  </div>
</article>`, boss);
}
