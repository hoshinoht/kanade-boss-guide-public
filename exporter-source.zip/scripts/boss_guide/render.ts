import type { DifficultyFacts, GuideItem, GuidePhase, KnowledgeDoc, Mechanic, Mission, Strategy, StrategyLevel } from '../../web/packages/api-types/src/manual';
import { LETTER, LEVEL_PIPS, LEVEL_WORD, SERIES_NAME, difficultyNotes, factTiles, figureParts, guideTabs, hpBreakdown, itemParts, missionPlace, phaseRuns, runLabel, sourceCounts, spellHp, stopLabel, tocSections } from '../../web/packages/ui/src/bosses/guide';

export interface Boss {
  slug: string;
  name: string;
  level?: number;
  thumbnail: string;
  portrait: string;
  image: string;
  video?: string;
  doc: KnowledgeDoc;
}

const upstream = 'https://github.com/hoshinoht/kanade-bot';
const escape = (value: string | number) => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;')
  .replaceAll('>', '&gt;').replaceAll('"', '&quot;');

export function bossPath(boss: Boss, fact?: DifficultyFacts) {
  const suffix = fact && fact !== boss.doc.difficulties?.[0] ? `${fact.name.toLowerCase()}/` : '';
  return `${boss.slug}/${suffix}`;
}

function page(title: string, lead: string, base: string, bosses: Boss[], body: string, current?: Boss) {
  const count = bosses.reduce((total, boss) => total + (boss.doc.difficulties?.length ?? 0), 0);
  return `<!doctype html>
<html lang="en" data-colorway="hoshino" data-theme="light">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="${escape(lead)}">
  <title>${escape(title)}</title>
  <link rel="stylesheet" href="${base}guide.css">
  ${current ? `<script type="module" src="${base}guide.js"></script>` : ''}
</head>
<body>
  <a class="skip" href="#guide">Skip to guide</a>
  <header class="page-line"><a href="${base || './'}">Bosses</a> <span><b>${bosses.length}</b> bosses · <b>${count}</b> difficulties</span></header>
  <main class="window" aria-label="Kanade Boss Guide">
    <div class="window-bar"><strong>The in-game list</strong><span>Level order</span></div>
    <div class="window-body${current ? ' window-body--detail' : ''}">
      ${catalog(bosses, base, current)}
      ${body}
    </div>
  </main>
  <footer>Part of the <a href="${upstream}">Kanade project</a>.</footer>
</body>
</html>\n`.replace(/[ \t]+$/gm, '');
}

function catalog(bosses: Boss[], base: string, current?: Boss) {
  const groups = [
    ['', bosses.filter((boss) => !boss.doc.event)],
    ['Event bosses', bosses.filter((boss) => boss.doc.event)],
  ] as const;
  return `<nav class="catalog" aria-label="Boss catalog">
    ${groups.filter(([, entries]) => entries.length).map(([label, entries]) => `${label ? `<h2 class="cap">${label}</h2>` : ''}
      <ul>${entries.map((boss) => `<li><a href="${base}${bossPath(boss)}"${boss === current ? ' aria-current="true"' : ''}>
        <img class="portrait" src="${base}${boss.thumbnail}" alt="" width="34" height="34">
        <span><strong>${escape(boss.name)}</strong>${boss.level ? `<small class="mono">Lv. ${escape(boss.level)}</small>` : ''}</span>
        ${boss.doc.event ? '<span class="catalog-chip">Seasonal boss</span>' : ''}
      </a></li>`).join('\n')}</ul>`).join('\n')}
  </nav>`;
}

export function indexPage(bosses: Boss[]) {
  const lead = 'Fight mechanics, phase notes, and difficulty stats for MapleSEA bosses.';
  return page('Kanade Boss Guide', lead, '', bosses, `<div id="guide" class="catalog-intro" tabindex="-1">
    <p class="cap">Checked-in boss knowledge</p><h1>MapleSEA Boss Guide</h1>
    <p class="guide-lead">${lead}</p><p>Choose a boss to open its guide.</p>
  </div>`);
}

const rowIcons = {
  risk: '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4m0 4h.01"/>',
  ok: '<polyline points="20 6 9 17 4 12"/>',
};

function rows(items: GuideItem[] = [], mark?: keyof typeof rowIcons) {
  if (!items.length) return '';
  const icon = mark ? `<span class="guide-row__mark guide-row__mark--${mark}"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${rowIcons[mark]}</svg></span>` : '';
  return `<ul class="guide-rows">${items.map((item) => {
    const { title, text } = itemParts(item);
    return `<li class="guide-row">${icon}<span class="guide-row__words">${title ? `<strong>${escape(title)}</strong>` : ''}<span>${escape(text)}</span></span></li>`;
  }).join('')}</ul>`;
}

function mechanicCard(mechanic: Mechanic) {
  let content;
  if (mechanic.kind === 'ledger') {
    content = `<ul class="guide-ledger">${mechanic.rows.map(({ label, value, direction }) => `<li><span>${escape(label)}</span><span class="guide-ledger__value mono${direction ? ` guide-${direction}` : ''}">${direction ? `<span aria-hidden="true">${direction === 'up' ? '▲' : '▼'}</span>` : ''}${escape(value)}${direction ? `<span class="vh">${direction === 'up' ? ', in your favour' : ', against you'}</span>` : ''}</span></li>`).join('')}</ul>`;
  } else if (mechanic.kind === 'zones') {
    content = `<ul class="guide-zones guide-zones--n${mechanic.zones.length}">${mechanic.zones.map(({ name, sub, tone }) => `<li class="guide-tone--${escape(tone ?? 'neutral')}"><strong>${escape(name)}</strong>${sub ? `<span>${escape(sub)}</span>` : ''}</li>`).join('')}</ul>`;
  } else {
    content = `<ol class="guide-scale">${mechanic.bands.map(({ label, tone, span }) => {
      const words = figureParts(label).map(({ text, figure }) => figure ? `<span class="guide-figure">${escape(text)}</span>` : escape(text)).join('');
      return `<li class="guide-tone--${escape(tone ?? 'neutral')}" style="flex-grow:${Number(span)}"><span>${words}</span></li>`;
    }).join('')}</ol>`;
  }
  return `<section class="guide-card guide-mechanic guide-mechanic--${mechanic.kind}"><h3>${escape(mechanic.title)}</h3>${content}${mechanic.note ? `<p class="note guide-mechanic__note">${escape(mechanic.note)}</p>` : ''}</section>`;
}

const difficultyTone = (name: string) => LETTER[name] ?? name.toLowerCase();
const bossTick = (name: string, extra = '') => `<span class="boss-tick boss-tick--${escape(difficultyTone(name))}${extra}">${escape(name.toUpperCase())}</span>`;
const statusChip = (text: string) => `<span class="status-chip status-chip--neutral">${escape(text)}</span>`;

function missionCard(mission: Mission, fact: DifficultyFacts, bosses: Boss[], base: string) {
  const stops = bosses.flatMap((boss) => (boss.doc.difficulties ?? []).flatMap((fact) =>
    fact.mission?.series === mission.series ? [{ boss, order: fact.mission.order, fact }] : [],
  )).sort((a, b) => a.order - b.order);
  const modifier = mission.modifier;
  const chips = [...(mission.needs ? [`Needs ${mission.needs}`] : []), ...(mission.rules ?? [])];
  return `<section id="mission" class="guide-mission" aria-labelledby="guide-mission-heading">
    <div class="guide-mission__head"><div><p class="cap">${escape(SERIES_NAME[mission.series])} mission · ${escape(missionPlace(mission.series, mission.order, stops.length))}</p>
      <h3 id="guide-mission-heading">${escape(mission.title)}</h3></div>${bossTick(fact.name)}</div>
    ${modifier ? `<p class="guide-mission__mod guide-mission__mod--${modifier.direction}"><span aria-hidden="true">${modifier.direction === 'up' ? '▲' : '▼'}</span><strong>${escape(modifier.text)}</strong><span class="guide-mission__dir">${modifier.direction === 'up' ? 'in your favour' : 'against you'}</span></p>` : ''}
    ${stops.length ? `<ol class="guide-mission__track guide-mission__track--n${stops.length}" aria-label="Mission order">${stops.map(({ boss, order, fact: stop }) => {
      const here = stop === fact;
      return `<li${here ? ' class="guide-mission__here" aria-current="step"' : ''}><span class="guide-mission__num mono">${escape(stopLabel(mission.series, order))}${here ? ' · now' : ''}</span>${here ? escape(boss.name) : `<a href="${base}${bossPath(boss, stop)}#mission">${escape(boss.name)}</a>`}</li>`;
    }).join('')}</ol>` : ''}
    ${chips.length ? `<ul class="guide-mission__chips">${chips.map((chip) => `<li>${statusChip(chip)}</li>`).join('')}</ul>` : ''}
  </section>`;
}

function hpCard(hp: NonNullable<ReturnType<typeof hpBreakdown>>, name: string) {
  const amount = (value: string) => `<span class="mono" title="${escape(spellHp(value))}"><span aria-hidden="true">${escape(value)}</span><span class="vh">${escape(spellHp(value))}</span></span>`;
  const total = hp.total ? `<span>Total HP</span>${amount(hp.total)}` : '';
  const tone = difficultyTone(name);
  return `<details class="guide-hp" id="hp"><summary class="guide-hp__head">
    <span class="cap"><span class="guide-hp__toggle">HP<span class="guide-hp__chevron" aria-hidden="true"></span></span></span>
    ${total ? `<span class="guide-hp__total guide-hp__total--head">${total}</span>` : ''}</summary>
    <div class="guide-hp__body">${total ? `<p class="guide-hp__total">${total}</p>` : ''}
    <ol class="guide-hp__phases">${hp.phases.map((phase) => {
      const bars = phase.bars.map((bar) => amount(bar));
      const barClass = `guide-hp__bar guide-hp__bar--${escape(tone)}`;
      return `<li class="guide-hp__phase"><p class="guide-hp__label"><span>${escape(phase.name)}</span>${phase.total ? amount(phase.total) : ''}</p>
        ${bars.length > 1 ? `<ul class="guide-hp__bars" aria-label="${bars.length} targets, each">${bars.map((bar) => `<li class="${barClass}">${bar}</li>`).join('')}</ul>` : `<p class="guide-hp__bars"><span class="${barClass}">${bars[0]}</span></p>`}</li>`;
    }).join('')}</ol></div></details>`;
}

function difficulty(name: string, tiles: ReturnType<typeof factTiles>, hp: ReturnType<typeof hpBreakdown>, notes: GuideItem[]) {
  return `<section class="guide-facts" aria-label="${escape(name)} facts">
  ${tiles.length ? `<dl id="facts" class="guide-tiles">${tiles.map(({ label, value, sub }) => `<div class="guide-tile"><dt class="cap">${escape(label)}</dt><dd class="guide-tile__value mono">${escape(value)}</dd>${sub ? `<dd class="guide-tile__sub">${escape(sub)}</dd>` : ''}</div>`).join('')}</dl>` : ''}
  ${hp ? hpCard(hp, name) : ''}
  ${notes.length ? `<section class="guide-notes" id="difficulty-notes"><h3 class="cap">${escape(name)} notes</h3>${rows(notes)}</section>` : ''}
</section>`;
}

function strategyCards(strategies: Strategy[]) {
  if (!strategies.length) return '';
  const meter = (label: string, level: StrategyLevel, kind: 'risk' | 'damage') => `<div class="guide-meter"><dt class="cap">${label}</dt><dd><span class="guide-pips guide-pips--${kind}-${level}" aria-hidden="true">${[1, 2, 3].map((pip) => `<i${pip <= LEVEL_PIPS[level] ? ' class="on"' : ''}></i>`).join('')}</span><strong>${LEVEL_WORD[level]}</strong></dd></div>`;
  return `<p class="note">Options, not orders: each trades risk against the damage it needs.</p>
    <ul class="guide-strategies">${strategies.map((strategy, index) => `<li class="guide-card guide-strategy"><h3>${escape(strategy.name)}</h3>
      <dl class="guide-strategy__meters">${meter('Risk', strategy.risk, 'risk')}${meter('Damage need', strategy.damage, 'damage')}</dl>
      <dl class="guide-strategy__when"><div><dt class="cap">When</dt><dd>${escape(strategy.when)}</dd></div><div><dt class="cap">Payoff</dt><dd>${escape(strategy.payoff)}</dd></div></dl>
      <ol class="guide-steps" id="strategy-steps-${index}" aria-label="Steps for ${escape(strategy.name)}">${strategy.steps.map((step, at) => `<li><span class="guide-steps__num mono" aria-hidden="true">${at + 1}</span><span>${escape(step)}</span></li>`).join('')}</ol>
      <button type="button" class="btn guide-strategy__toggle" aria-expanded="false" aria-controls="strategy-steps-${index}" hidden>Show ${strategy.steps.length} step${strategy.steps.length === 1 ? '' : 's'}</button>
    </li>`).join('')}</ul>`;
}

function phaseTimeline(phases: GuidePhase[]) {
  if (!phases.length) return '';
  const runs = phaseRuns(phases);
  const labelled = runs.some((run) => runLabel(run));
  const bracket = (run: (typeof runs)[number]) => `${run.cycle ? '<span class="guide-timeline__loop" aria-hidden="true">↻</span>' : ''}${escape(runLabel(run))}`;
  return `<div class="guide-timeline guide-timeline--n${phases.length}${labelled ? ' guide-timeline--labelled' : ''}">
    ${phases.length > 1 ? `<div class="guide-timeline__bar" role="tablist" aria-label="Phases" hidden>${runs.map((run) => {
      const label = runLabel(run);
      return `<div class="guide-timeline__run${label ? ' guide-timeline__run--group' : ''}" role="presentation" style="grid-column:span ${run.phases.length}"><span class="guide-timeline__bracket" aria-hidden="true">${bracket(run)}</span>
        ${run.phases.map(({ phase, index }) => `<button type="button" id="phase-tab-${index}" class="guide-timeline__seg ${phase.tone ? `guide-tone--${escape(phase.tone)}` : 'guide-timeline__seg--plain'}" role="tab" aria-controls="phase-panel-${index}">${label ? `<span class="vh">${escape(label)}: </span>` : ''}<strong>${escape(phase.name)}</strong>${phase.tag ? `<span class="guide-timeline__tag">${escape(phase.tag)}</span>` : ''}</button>`).join('')}</div>`;
    }).join('')}</div>` : ''}
    ${runs.flatMap((run) => run.phases.map(({ phase, index }) => `<section class="guide-card guide-phase" id="phase-panel-${index}">
      <div class="guide-phase__head">${runLabel(run) ? `<p class="cap">${bracket(run)}</p>` : ''}<h3>${escape(phase.name)}</h3>${phase.tag ? `<p class="guide-phase__tag">${escape(phase.tag)}</p>` : ''}</div>
      <ul>${phase.items.map((item) => { const { title, text } = itemParts(item); return `<li>${title ? `<strong>${escape(title)}</strong> ` : ''}${escape(text)}</li>`; }).join('')}</ul></section>`)).join('')}
  </div>`;
}

export function bossPage(boss: Boss, bosses: Boss[], date: string, base: string, fact?: DifficultyFacts) {
  const { doc } = boss;
  const lead = doc.lead ?? doc.summary;
  const facts = doc.difficulties ?? [];
  const tiles = fact ? factTiles(fact) : [];
  const hp = hpBreakdown(fact?.hp);
  const notes = fact ? difficultyNotes(doc, fact) : [];
  const toc = tocSections({ mission: Boolean(fact?.mission), facts: tiles.length > 0, hp: Boolean(hp), notes: notes.length && fact ? `${fact.name} notes` : null });
  const list = (label: string, items: GuideItem[] = [], mark?: keyof typeof rowIcons) => items.length ? `<section class="guide-list"><h3 class="cap">${label}</h3>${rows(items, mark)}</section>` : '';
  const spec = fact?.recommended_spec;
  const tabs = new Map<string, number | null>(guideTabs(doc).map(({ id, count }) => [id, count]));
  const sections = [
    ['overview', 'Overview', `${doc.mechanics?.length ? `<div class="guide-mechanics">${doc.mechanics.map(mechanicCard).join('')}</div>` : ''}
      ${list('Core', doc.core)}${list('Danger', doc.danger, 'risk')}${list('Tips', doc.tips, 'ok')}`],
    ['phases', 'Phases', phaseTimeline(doc.phases ?? [])],
    ['strategies', 'Strategies', strategyCards(doc.strategies ?? [])],
    ['notes', 'Notes', `${rows(doc.notes)}${spec && (spec.value || spec.parties?.length) ? `<p><strong>Recommended · ${escape(fact!.name)}</strong> ${escape(spec.text)}</p>` : ''}`],
    ['sources', 'Sources', `<ul class="guide-source-kinds" aria-label="Sources by kind">${sourceCounts(doc.sources).map(({ kind, count }) => `<li><span class="status-chip status-chip--neutral">${escape(kind)} <b class="mono">${count}</b></span></li>`).join('')}</ul>
      <ul class="guide-sources">${doc.sources.map((source) => {
        const url = new URL(source.url);
        if (url.protocol !== 'https:' || url.username || url.password) throw new Error(`Invalid source URL for ${boss.slug}`);
        const meta = [`by ${source.author}`, source.kind, `fetched ${source.fetched}`, ...(source.updated ? [`updated ${source.updated}`] : [])];
        return `<li><a href="${escape(url.href)}" rel="noopener noreferrer" target="_blank">${escape(source.title)}</a><span class="guide-sources__meta">${escape(meta.join(' · '))}</span></li>`;
      }).join('')}</ul><p class="note">Our own paraphrase of these sources; the authors are credited above.</p>`],
  ].filter(([, , content]) => content?.trim());
  const sectionLinks = sections.map(([id, label]) => `<li><a href="#${id}">${label}</a></li>`).join('');
  const sectionPills = sections.map(([id, label]) => {
    const count = tabs.get(id!);
    return `<li><a class="ptab" href="#${id}">${label}${count ? ` <span class="ptab__count mono">${count}</span>` : ''}</a></li>`;
  }).join('');
  const title = [boss.name, fact?.name, 'Kanade Boss Guide'].filter(Boolean).join(' · ');
  return page(title, lead, base, bosses, `<article>
  <a class="catalog-back" href="${base}">← Back to the catalog</a>
  <header class="hero">
    <div class="hero-art" aria-hidden="true">
      <img src="${base}${boss.image}" alt="">
      ${boss.video ? `<video poster="${base}${boss.image}" muted autoplay loop playsinline preload="metadata" disablepictureinpicture disableremoteplayback>
        <source src="${base}${boss.video}" type="video/mp4" media="(prefers-reduced-motion: no-preference)">
      </video>` : ''}
    </div>
    <div class="hero-identity">
      <img class="portrait" src="${base}${boss.portrait}" alt="" width="72" height="72">
      <div><p class="cap">Checked-in boss knowledge</p><h1>${escape(boss.name)}${fact ? bossTick(fact.name, ' hero-difficulty') : ''}</h1>
        <p class="hero-meta">${boss.level ? `Lv. ${escape(boss.level)} · ` : ''}researched <time datetime="${escape(date)}">${escape(date)}</time> · <a class="mono" href="${upstream}/blob/master/boss/knowledge/${boss.slug}.yaml">boss/knowledge/${boss.slug}.yaml</a></p></div>
      ${doc.event ? `<span class="catalog-chip">${escape(doc.event.name)}</span>` : ''}
    </div>
    ${boss.video ? '<label class="hero-motion"><input type="checkbox" checked> Animate artwork</label>' : ''}
  </header>
  <div class="guide-layout" id="guide" role="region" aria-label="Boss guide" tabindex="0">
    <div class="guide-content">
      ${fact ? `<nav id="difficulties" class="difficulty-switch" aria-label="Difficulty"><span class="cap">Difficulty</span><ul class="seg">${facts.map((choice) => `<li><a class="difficulty-${escape(difficultyTone(choice.name))}" href="${base}${bossPath(boss, choice)}"${fact === choice ? ' aria-current="page"' : ''}>${escape(choice.name)}</a></li>`).join('')}</ul></nav>` : ''}
      ${fact?.mission ? missionCard(fact.mission, fact, bosses, base) : ''}
      <p class="guide-lead">${escape(lead)}</p>
      ${doc.event ? `<p class="event-note"><strong>Event boss.</strong> ${escape(doc.event.availability)}</p>` : ''}
      ${fact ? difficulty(fact.name, tiles, hp, notes) : ''}
      <nav class="section-links" aria-label="Guide sections"><ul class="guide-tabs">${sectionPills}</ul></nav>
      ${sections.map(([id, label, content]) => `<section class="guide-panel guide-section" id="${id}"><h2>${label}</h2>${content}</section>`).join('\n')}
    </div>
    <aside><nav class="toc" aria-label="On this page"><h2 class="cap">On this page</h2>
      ${toc.length ? `<ul>${toc.map(({ key, label }) => `<li><a href="#${key === 'notes' ? 'difficulty-notes' : key}">${escape(label)}</a></li>`).join('')}</ul>` : ''}
      <h3 class="cap">Guide</h3><ul>${sectionLinks}</ul>
    </nav></aside>
  </div>
</article>`, boss);
}
