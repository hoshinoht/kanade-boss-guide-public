import type { DifficultyFacts, GuideItem, KnowledgeDoc, Mechanic, Mission } from '../../web/packages/api-types/src/manual';
import { LEVEL_WORD, SERIES_NAME, difficultyNotes, factTiles, hpBreakdown, itemParts, phaseRuns, runLabel, spellHp, stopLabel } from '../../web/packages/ui/src/bosses/guide';

export interface Boss {
  slug: string;
  name: string;
  level?: number;
  portrait: string;
  image: string;
  video?: string;
  doc: KnowledgeDoc;
}

const upstream = 'https://github.com/hoshinoht/kanade-bot';
const escape = (value: string | number) => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;')
  .replaceAll('>', '&gt;').replaceAll('"', '&quot;');

function page(title: string, lead: string, base: string, body: string) {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="${escape(lead)}">
  <title>${escape(title)}</title>
  <link rel="stylesheet" href="${base}guide.css">
</head>
<body>
  <header class="masthead"><a href="${base || './'}">Kanade Boss Guide</a></header>
  <main>${body}</main>
  <footer>Part of the <a href="${upstream}">Kanade project</a>.</footer>
</body>
</html>\n`.replace(/[ \t]+$/gm, '');
}

export function indexPage(bosses: Boss[]) {
  const lead = 'Fight mechanics, phase notes, and difficulty stats for MapleSEA bosses.';
  const groups = [
    ['Bosses', bosses.filter((boss) => !boss.doc.event)],
    ['Event bosses', bosses.filter((boss) => boss.doc.event)],
  ] as const;
  return page('Kanade Boss Guide', lead, '', `<h1>MapleSEA Boss Guide</h1><p class="guide-lead">${lead}</p>
${groups.filter(([, entries]) => entries.length).map(([label, entries]) => `<section><h2>${label}</h2>
  <ul class="catalog">${entries.map((boss) => `<li><a href="${boss.slug}/">
    <img src="${boss.portrait}" alt="" width="48" height="48" loading="lazy">
    <span><strong>${escape(boss.name)}</strong>${boss.level ? `<small>Level ${escape(boss.level)}</small>` : ''}</span>
  </a></li>`).join('\n')}</ul></section>`).join('\n')}`);
}

function rows(items: GuideItem[] = []) {
  if (!items.length) return '';
  return `<ul class="guide-rows">${items.map((item) => {
    const { title, text } = itemParts(item);
    return `<li>${title ? `<strong>${escape(title)}</strong> ` : ''}${escape(text)}</li>`;
  }).join('')}</ul>`;
}

function mechanicCard(mechanic: Mechanic) {
  let content;
  if (mechanic.kind === 'ledger') {
    content = `<dl class="ledger">${mechanic.rows.map(({ label, value, direction }) => `<div><dt>${escape(label)}</dt><dd>${direction ? (direction === 'up' ? '↑ ' : '↓ ') : ''}${escape(value)}</dd></div>`).join('')}</dl>`;
  } else {
    const bands = mechanic.kind === 'zones'
      ? mechanic.zones.map(({ name, sub, tone }) => ({ label: name, sub, tone, span: 1 }))
      : mechanic.bands.map((band) => ({ ...band, sub: undefined }));
    content = `<ul class="bands">${bands.map(({ label, sub, tone, span }) => `<li data-tone="${escape(tone ?? '')}" style="flex-grow:${Number(span)}"><strong>${escape(label)}</strong>${sub ? `<small>${escape(sub)}</small>` : ''}</li>`).join('')}</ul>`;
  }
  return `<div class="guide-card"><h3>${escape(mechanic.title)}</h3>${content}${mechanic.note ? `<p>${escape(mechanic.note)}</p>` : ''}</div>`;
}

function missionCard(mission: Mission, current: Boss, bosses: Boss[]) {
  const stops = bosses.flatMap((boss) => (boss.doc.difficulties ?? []).flatMap(({ mission: stop, name }) =>
    stop?.series === mission.series ? [{ boss, order: stop.order, difficulty: name.toLowerCase() }] : [],
  )).sort((a, b) => a.order - b.order);
  const modifier = mission.modifier;
  return `<div class="guide-card"><h4>${escape(SERIES_NAME[mission.series])} · ${escape(mission.title)}</h4>
    ${modifier ? `<p>${modifier.direction === 'up' ? '↑' : '↓'} ${escape(modifier.text)}</p>` : ''}
    ${mission.needs ? `<p>${escape(mission.needs)}</p>` : ''}${rows(mission.rules)}
    <ul class="pills">${stops.map(({ boss, order, difficulty }) => {
      const label = `${escape(stopLabel(mission.series, order))} · ${escape(boss.name)}`;
      return `<li>${boss === current && order === mission.order ? `<strong>${label}</strong>` : `<a href="../${boss.slug}/#${escape(difficulty)}">${label}</a>`}</li>`;
    }).join('')}</ul></div>`;
}

function difficulty(fact: DifficultyFacts, boss: Boss, bosses: Boss[]) {
  const hp = hpBreakdown(fact.hp);
  const spec = fact.recommended_spec;
  const tiles = factTiles(fact);
  const hpValue = (value: string) => `<abbr title="${escape(spellHp(value))}">${escape(value)}</abbr>`;
  return `<section class="difficulty" id="${escape(fact.name.toLowerCase())}">
  <h3>${escape(fact.name)}</h3>
  ${fact.mission ? missionCard(fact.mission, boss, bosses) : ''}
  ${tiles.length ? `<dl class="guide-tiles">${tiles.map(({ label, value, sub }) => `<div><dt>${escape(label)}</dt><dd>${escape(value)}${sub ? `<small>${escape(sub)}</small>` : ''}</dd></div>`).join('')}</dl>` : ''}
  ${hp ? `<details class="guide-card"><summary>HP by phase${hp.total ? ` · ${hpValue(hp.total)} total` : ''}</summary>
    <dl class="ledger">${hp.phases.map(({ name, total, bars }) => `<div><dt>${escape(name)}</dt><dd>${bars.length > 1 ? `${bars.length} × ` : ''}${hpValue(bars[0]!)}${total ? ` (${hpValue(total)} total)` : ''}</dd></div>`).join('')}</dl></details>` : ''}
  ${spec && (spec.value || spec.parties?.length) ? `<p>${escape(spec.text)}</p>` : ''}
  ${rows(difficultyNotes(boss.doc, fact))}
</section>`;
}

export function bossPage(boss: Boss, bosses: Boss[], date: string) {
  const { doc } = boss;
  const lead = doc.lead ?? doc.summary;
  const facts = doc.difficulties ?? [];
  const sections = [
    ['overview', 'Overview', `${doc.mechanics?.map(mechanicCard).join('') ?? ''}${rows(doc.core)}
      ${doc.danger.length ? `<h3>Danger</h3>${rows(doc.danger)}` : ''}${doc.tips.length ? `<h3>Tips</h3>${rows(doc.tips)}` : ''}`],
    ['difficulties', 'Difficulties', facts.length ? `<ul class="pills">${facts.map(({ name }) => `<li><a href="#${escape(name.toLowerCase())}">${escape(name)}</a></li>`).join('')}</ul>${facts.map((fact) => difficulty(fact, boss, bosses)).join('')}` : ''],
    ['phases', 'Phases', phaseRuns(doc.phases ?? []).map((run) => `<div class="phase-run">
      ${run.group ? `<h3>${escape(runLabel(run))}</h3>` : ''}
      ${run.phases.map(({ phase }) => `<details class="guide-card" data-tone="${escape(phase.tone ?? '')}" open><summary>${escape(phase.name)}${phase.tag ? ` <small>${escape(phase.tag)}</small>` : ''}</summary>${rows(phase.items)}</details>`).join('')}</div>`).join('')],
    ['strategies', 'Strategies', (doc.strategies ?? []).map((strategy) => `<div class="guide-card"><h3>${escape(strategy.name)}</h3>
      <small>${escape(LEVEL_WORD[strategy.risk])} risk · ${escape(LEVEL_WORD[strategy.damage])} damage requirement</small>
      <p>${escape(strategy.when)}</p><ol>${strategy.steps.map((step) => `<li>${escape(step)}</li>`).join('')}</ol><p><strong>Payoff</strong> ${escape(strategy.payoff)}</p></div>`).join('')],
    ['notes', 'Notes', rows(doc.notes)],
    ['sources', 'Sources', `<p>Research checked <time datetime="${escape(date)}">${escape(date)}</time>.</p>
      <ul class="guide-rows">${doc.sources.map((source) => {
        const url = new URL(source.url);
        if (url.protocol !== 'https:' || url.username || url.password) throw new Error(`Invalid source URL for ${boss.slug}`);
        return `<li><a href="${escape(url.href)}">${escape(source.title)}</a><small>${escape(source.author)} · ${escape(source.kind)}</small></li>`;
      }).join('')}</ul>`],
  ].filter(([, , content]) => content?.trim());
  const media = boss.video
    ? `<video src="../${boss.video}" poster="../${boss.image}" controls preload="none" playsinline aria-label="${escape(boss.name)} animation"></video>`
    : `<img src="../${boss.image}" alt="${escape(boss.name)}">`;
  return page(`${boss.name} · Kanade Boss Guide`, lead, '../', `<article>
  <div class="hero">
    <div><h1>${escape(boss.name)}</h1><p class="guide-lead">${escape(lead)}</p>${doc.event ? `<p>${escape(doc.event.availability)}</p>` : ''}</div>
    ${media}
  </div>
  <nav aria-label="On this page"><ul class="pills">${sections.map(([id, label]) => `<li><a href="#${id}">${label}</a></li>`).join('')}</ul></nav>
  ${sections.map(([id, label, content]) => `<section id="${id}"><h2>${label}</h2>${content}</section>`).join('\n')}
</article>`);
}
